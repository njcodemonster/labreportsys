<h1>Report Form :</h1>
<form action="7CReport.php" method="POST" enctype= "multipart/form-data">
    <input type="text" name="PrivateKey" value="6dde1e8317ab07d722c02b3bdba8d5a4" >
    <br><br>
    <input type="text" name="Passcode" value="1234" >
    <br><br>
    Name : <input type="text" name="PatientName" value="abc" >
    <br><br>
    phoneNumber : <input type="text" name="phoneNumber" value="090909" >
    <br><br>
    email : <input type="text" name="email" value="test@gmail.com" >
    <br><br>
    reportName : <input type="text" name="reportName" value="My First Report" >
    <br><br>
    <input type="file" name="file">
    <br><br>
    <br> <input type="submit" value="Submit">
</form>

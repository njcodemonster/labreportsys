<h1>Create New Lab :</h1>
<form action="createnew.php" method="POST" enctype= "multipart/form-data">
    <input type="text" name="masterKey" value="1123581321" >
    <br><br>
    <input type="text" name="labSelectedPasscode" value="1234" >
    <br><br>
    <input type="text" name="labName" value="Test 123" >
    <br><br>
    <input type="text" name="labPhone" value="123456" >
    <br><br>
    <input type="text" name="contactPersonName" value="adb@gmail.com" >
    <br><br>
    <br> <input type="submit" value="Submit">
</form>

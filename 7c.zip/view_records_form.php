<h1>View Record :</h1>
<form action="viewrecords.php" method="POST" enctype= "multipart/form-data">
    <input type="text" name="masterKey" value="1123581321" >
    <br><br>
    Name : <input type="text" name="name" value="Patient 1" >
    <br><br>
    Phone : <input type="text" name="phone" value="123456" >
    <br><br>
    Email : <input type="text" name="email" value="adb1@gmail.com" >
    <br><br>
    <br> <input type="submit" value="Submit">
</form>
